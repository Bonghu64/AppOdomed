package com.example.odomedapp.data

data class User(
    val id_usuario: Int,
    val nombres: String,
    val email: String
)